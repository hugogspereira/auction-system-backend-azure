package scc.utils;

public enum AuctionStatus {
    OPEN, CLOSED, DELETED
}
