package scc.serverless;

import com.azure.core.util.BinaryData;
import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobContainerClientBuilder;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.BindingName;
import com.microsoft.azure.functions.annotation.BlobTrigger;
import com.microsoft.azure.functions.annotation.FunctionName;

public class BlobReplicationFunction {

	private static final String BLOB_KEY_REPLICA = "BlobStoreConnectionReplica";
	private static final String CONTAINER_NAME = "images";

	@FunctionName("blob-replication")
	public void replicateBlobStore(@BlobTrigger(name = "replicateBlobStore",
			dataType = "binary",
			path = "images/{name}",
			connection = "BlobStoreConnection")
								byte[] content,
								@BindingName("name") String blobname,
								final ExecutionContext context) {

		context.getLogger().info("Invoked blob-replication");

		// Get connection string in the storage access keys page
		String storageConnectionString = System.getenv(BLOB_KEY_REPLICA);
		// Get container client
		BlobContainerClient blobContainerClient = new BlobContainerClientBuilder()
				.connectionString(storageConnectionString)
				.containerName(CONTAINER_NAME)
				.buildClient();

		// Get client to blob
		BlobClient blob = blobContainerClient.getBlobClient(blobname);
		// Upload contents from BinaryData (check documentation for other alternatives)
		if(!blob.exists()) {
			blob.upload(BinaryData.fromBytes(content));
		}

	}
}
