package scc.serverless;

import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.TimerTrigger;
import scc.dao.AuctionDAO;
import scc.layers.CosmosDBLayer;
import scc.layers.RedisCosmosLayer;
import scc.utils.AuctionStatus;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class CloseAuctionsFunction {

	private CosmosDBLayer cosmosDB = CosmosDBLayer.getInstance();
	private RedisCosmosLayer redisCosmos = RedisCosmosLayer.getInstance();

	@FunctionName("close-auctions")
	public void closeAuctionsFunctions( @TimerTrigger(name = "periodicCloseAuctions",
			schedule = "* */5 * * * *")
								String timerInfo,
								ExecutionContext context) {
		context.getLogger().info("Invoked at "+timerInfo);

		LocalDateTime localDateTime = LocalDateTime.now(ZoneId.systemDefault());

		List<AuctionDAO> openAuctions = cosmosDB.getOpenAuctions(localDateTime);
		openAuctions.sort(new Comparator<AuctionDAO>() {
			@Override
			public int compare(AuctionDAO auction1, AuctionDAO auction2) {
				LocalDateTime t1 = LocalDateTime.parse(auction1.getEndTime());
				LocalDateTime t2 = LocalDateTime.parse(auction2.getEndTime());
				return t1.compareTo(t2);
			}
		});

		for(AuctionDAO auctionDAO : openAuctions) {
			LocalDateTime t1 = LocalDateTime.parse(auctionDAO.getEndTime());
			try {
				Thread.sleep(LocalDateTime.now(ZoneId.systemDefault()).until(t1, ChronoUnit.MILLIS));
				auctionDAO.setStatus(AuctionStatus.CLOSED);
				redisCosmos.replaceAuction(auctionDAO);
			} catch (InterruptedException e) {
				System.err.println("Something happened!");
			}
		}
	}
}
