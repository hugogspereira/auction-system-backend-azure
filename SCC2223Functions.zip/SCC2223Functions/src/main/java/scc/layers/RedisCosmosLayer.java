package scc.layers;

import com.azure.cosmos.CosmosException;
import scc.cache.RedisCache;
import scc.dao.AuctionDAO;

/**
 * Layer with cache and database
 */
public class RedisCosmosLayer {

	private final CosmosDBLayer cosmosDBLayer;
	private final RedisCache redisCache;

	private static RedisCosmosLayer instance;

	public static synchronized RedisCosmosLayer getInstance() {
		if( instance != null)
			return instance;

		instance = new RedisCosmosLayer();
		return instance;
	}

	public RedisCosmosLayer() {
		this.cosmosDBLayer = CosmosDBLayer.getInstance();
		this.redisCache = RedisCache.getInstance();
	}

	public void replaceAuction(AuctionDAO auction) {
		try {
			cosmosDBLayer.replaceAuction(auction);
			redisCache.replaceAuction(auction);
		}
		catch (CosmosException e) {
			System.err.println((e.getStatusCode()));
		}
	}
}
