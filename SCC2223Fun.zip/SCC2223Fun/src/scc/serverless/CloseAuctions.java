package scc.serverless;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.TimerTrigger;
import redis.clients.jedis.Jedis;
import scc.cache.RedisCache;
import scc.dao.AuctionDAO;
import scc.layers.CosmosDBLayer;
import scc.utils.AuctionStatus;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

public class CloseAuctions {

	private CosmosDBLayer cosmosDB = CosmosDBLayer.getInstance();

	@FunctionName("close-ended-auctions")
	public void closeAuctionsFunctions( @TimerTrigger(name = "periodicCloseAuctions",
			schedule = "* */1 * * * *")
								String timerInfo,
								ExecutionContext context) {

		LocalDateTime localDateTime = LocalDateTime.now(ZoneId.systemDefault());
		ObjectMapper mapper = new ObjectMapper();
		try (Jedis jedis = RedisCache.getCachePool().getResource())
		{
			List<AuctionDAO> auctionsClosed = cosmosDB.getAuctionsClosed(localDateTime);
			for (AuctionDAO auction: auctionsClosed)
			{
				auction.setStatus(AuctionStatus.CLOSED);

				jedis.set("auction:"+auction.getId(), mapper.writeValueAsString(auction));
				cosmosDB.replaceAuction(auction);
			}
			jedis.set("serverless-time:", localDateTime.toString());
		}
		catch(JsonProcessingException e) {
			System.out.println("Redis Cache: unable to put the closed auction in cache.\n"+e.getMessage());
		}
	}
}
