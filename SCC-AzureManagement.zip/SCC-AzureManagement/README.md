# SCC2223

## Group: 58010-58081-59187

<ul>
  <li>Hugo Pereira    - 58010 (hg.pereira@campus.fct.unl.pt)</li>
  <li>Ana Canelhas    - 58081 (a.canelhas@campus.fct.unl.pt)</li>
  <li>Bernardo Calvo  - 59187 (b.calvo@campus.fct.unl.pt).</li>
</ul>

Repository for the Cloud Computing Systems Course of 2022/2023, which consists in the back-end of a auction website.
