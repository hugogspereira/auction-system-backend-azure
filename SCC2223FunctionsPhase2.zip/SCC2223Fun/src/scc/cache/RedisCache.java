package scc.cache;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import scc.dao.AuctionDAO;
import static scc.utils.AzureProperties.REDIS_PORT;
import static scc.utils.AzureProperties.REDIS_URL;

public class RedisCache {

    public static final boolean IS_ACTIVE = true;
    private static final String RedisHostname = System.getenv(REDIS_URL);
    private static final String RedisPort = System.getenv(REDIS_PORT);

    //private static final String RedisKey = System.getenv(REDIS_KEY);

    private static JedisPool instance;
    private static RedisCache redisCache;

    public static final String AUCTION_KEY = "auction:";

    private static final String SESSION_KEY = "session:";

    private static final int SESSION_EXP_TIME = 3600;
    private static final int DEFAULT_EXP_TIME = 600;

    public RedisCache() {
        getCachePool();
    }

    public synchronized static JedisPool getCachePool() {
        if (instance != null)
            return instance;

        final JedisPoolConfig poolConfig = new JedisPoolConfig();
        poolConfig.setMaxTotal(128);
        poolConfig.setMaxIdle(128);
        poolConfig.setMinIdle(16);
        poolConfig.setTestOnBorrow(true);
        poolConfig.setTestOnReturn(true);
        poolConfig.setTestWhileIdle(true);
        poolConfig.setNumTestsPerEvictionRun(3);
        poolConfig.setBlockWhenExhausted(true);
        instance = new JedisPool(poolConfig, RedisHostname, Integer.parseInt(RedisPort), 1000);

        return instance;
    }

    public static synchronized RedisCache getInstance() {
        if (redisCache != null) {
            return redisCache;
        }
        redisCache = new RedisCache();
        return redisCache;
    }


    public void replaceAuction(AuctionDAO auction) {
        ObjectMapper mapper;
        try(Jedis jedis = instance.getResource()) {
            mapper = new ObjectMapper();
            jedis.set(AUCTION_KEY+auction.getId(), mapper.writeValueAsString(auction));
            jedis.expire(AUCTION_KEY+auction.getId(), DEFAULT_EXP_TIME);
        } catch (JsonProcessingException e) {
            System.out.println("Redis Cache: unable to put the auction in cache.\n"+e.getMessage());
        }
    }
}
