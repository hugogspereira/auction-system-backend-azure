package scc.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class AzureProperties
{
	public static final String MONGODB_HOSTNAME = "MONGODB_HOSTNAME";
	public static final String MONGODB_DATABASE = "MONGODB_DATABASE";
	public static final String MONGODB_PORT = "MONGODB_PORT";
	public static final String MONGODB_USERNAME = "MONGODB_USERNAME";
	public static final String MONGODB_PASSWORD = "MONGODB_PASSWORD";
	public static final String REDIS_KEY = "REDIS_KEY";
	public static final String REDIS_URL = "REDIS_URL";
	public static final String REDIS_PORT = "REDIS_PORT";

	public static final String PROPS_FILE = "azurekeys-westeurope.props";
	private static Properties props;
	
	public static synchronized Properties getProperties() {
		if( props == null) {
			props = new Properties();
			try {
				props.load( new FileInputStream(PROPS_FILE));
			} catch (IOException e) {
				// do nothing
			}
		}
		return props;
	}

}
