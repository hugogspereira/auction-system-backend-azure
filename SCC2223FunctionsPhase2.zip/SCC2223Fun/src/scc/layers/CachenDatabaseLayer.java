package scc.layers;

import jakarta.ws.rs.WebApplicationException;
import scc.cache.RedisCache;
import scc.dao.AuctionDAO;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Layer with cache and database
 */
public class CachenDatabaseLayer {

	private final MongoDBLayer databaseLayer;
	private final RedisCache redisCache;
	private static CachenDatabaseLayer instance;

	public static synchronized CachenDatabaseLayer getInstance() {
		if( instance != null)
			return instance;

		instance = new CachenDatabaseLayer();
		return instance;
	}

	public CachenDatabaseLayer() {
		this.databaseLayer = MongoDBLayer.getInstance();
		this.redisCache = RedisCache.getInstance();
	}

	// AUCTIONS
	public void replaceAuction(AuctionDAO auction) {
		try {
			auction = databaseLayer.replaceAuction(auction);
			if(RedisCache.IS_ACTIVE) {
				redisCache.replaceAuction(auction);
			}
		}
		catch (Exception e) {
			throw new WebApplicationException(e);
		}
	}

	public List<AuctionDAO> getOpenAuctions(LocalDateTime beginNow) {
		try {
			return databaseLayer.getOpenAuctions(beginNow);
		}
		catch (Exception e) {
			throw new WebApplicationException(e);
		}
	}


}