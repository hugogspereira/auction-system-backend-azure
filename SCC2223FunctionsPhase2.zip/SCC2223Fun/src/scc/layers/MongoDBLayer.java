package scc.layers;

import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import scc.dao.AuctionDAO;
import scc.utils.AuctionStatus;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;
import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static scc.utils.AzureProperties.*;

public class MongoDBLayer {

	private static final String AUCTIONS = "auctions";

	private static final String DB_HOSTNAME = System.getenv(MONGODB_HOSTNAME);
	private static final String DB_PORT = System.getenv(MONGODB_PORT);
	private static final String DB_NAME = System.getenv(MONGODB_DATABASE);
	private static final String DB_USERNAME = System.getenv(MONGODB_USERNAME);
	private static final String DB_PASSWORD = System.getenv(MONGODB_PASSWORD);

	private static MongoDBLayer instance;

	public static synchronized MongoDBLayer getInstance() {
		if(instance != null) {
			return instance;
		}
		// mongodb://[username:password@]host1[:port1][,...hostN[:portN]][/[defaultauthdb][?options]]
		String connectionUri = String.format("mongodb://%s:%s@%s:%s", DB_USERNAME, DB_PASSWORD, DB_HOSTNAME, DB_PORT);
		MongoClient client = MongoClients.create(connectionUri);

		instance = new MongoDBLayer(client);
		return instance;
	}

	private MongoClient client;
	private MongoDatabase db;
	private MongoCollection<AuctionDAO> auctions;

	public MongoDBLayer(MongoClient client) {
		this.client = client;
	}

	private synchronized void init() {
		if( db != null)
			return;

		CodecRegistry pojoCodecRegistry = fromRegistries(MongoClientSettings.getDefaultCodecRegistry(), fromProviders(PojoCodecProvider.builder().automatic(true).build()));

		db = client.getDatabase(DB_NAME).withCodecRegistry(pojoCodecRegistry);
		auctions =  db.getCollection(AUCTIONS, AuctionDAO.class);
	}

	// Auctions
	public AuctionDAO replaceAuction(AuctionDAO auction) {
		init();

		auctions.replaceOne(Filters.eq("_id",auction.getId()), auction);
		return auction;
	}

	public List<AuctionDAO> getOpenAuctions(LocalDateTime beginNow) {
		init();

		LocalDateTime endNow = beginNow.plusMinutes(5);

		return auctions.find(Filters.and( Filters.gte("endTime", beginNow.toString()), Filters.lt("endTime",endNow.toString()), Filters.eq("status", AuctionStatus.OPEN)), AuctionDAO.class).into(new ArrayList<>());
	}

}
