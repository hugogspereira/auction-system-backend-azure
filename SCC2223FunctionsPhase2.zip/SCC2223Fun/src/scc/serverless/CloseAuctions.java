package scc.serverless;

import scc.dao.AuctionDAO;
import scc.layers.CachenDatabaseLayer;
import scc.utils.AuctionStatus;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;

public class CloseAuctions {

	public static void main(String[] args) {

		LocalDateTime beginNow = LocalDateTime.now(ZoneId.systemDefault());
		CachenDatabaseLayer cacheNdatabase = CachenDatabaseLayer.getInstance();

		List<AuctionDAO> openAuctions = cacheNdatabase.getOpenAuctions(beginNow);
		openAuctions.sort(new Comparator<AuctionDAO>() {
			@Override
			public int compare(AuctionDAO auction1, AuctionDAO auction2) {
				LocalDateTime t1 = LocalDateTime.parse(auction1.getEndTime());
				LocalDateTime t2 = LocalDateTime.parse(auction2.getEndTime());
				return t1.compareTo(t2);
			}
		});

		for(AuctionDAO auctionDAO : openAuctions) {
			LocalDateTime t1 = LocalDateTime.parse(auctionDAO.getEndTime());
			try {
				Thread.sleep(LocalDateTime.now(ZoneId.systemDefault()).until(t1, ChronoUnit.MILLIS));
				auctionDAO.setStatus(AuctionStatus.CLOSED);
				cacheNdatabase.replaceAuction(auctionDAO);
			} catch (InterruptedException e) {
				System.err.println("Something happened!");
			}
		}

	}
}
